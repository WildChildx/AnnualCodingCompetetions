for (auto i:dice)
// {
//     cout<<i<<" ";
// }